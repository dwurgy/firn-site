FIRN PRESS KIT
firnbrowser.com/press

A calm browser, made for Mac.
Vertical tabs, spaces, and split view, without the learning curve.


FACT SHEET

Name:        Firn
Made by:     David Wurgler, Salem, Oregon
Released:    Firn 1.0, October 27, 2026
Platform:    Mac (macOS 14 or later). Coming soon to iPhone and iPad.
Price:       Free
Source:      Open source under MPL-2.0, github.com/dwurgy/firn
Built with:  Swift, SwiftUI, and WebKit, the engine Safari uses
Website:     https://firnbrowser.com
Contact:     hello@firnbrowser.com


SHORT DESCRIPTION

A calm, minimalist browser with vertical tabs, spaces, and split view. Now available for Mac.


ABOUT FIRN

Spaces: Keep Work and Personal apart, each with its own tabs and color. Switching feels like opening a different browser.

Basecamp: Your everyday sites, like mail and calendar, always one click away at the top of the sidebar, in every space.

Lookout: Peek at a link in a floating panel without leaving your page. Keep it as a tab if you want it.

Split view: Two tabs side by side, each with its own address. Drag the gap to make room.

Nothing collected: No tracking, no telemetry, no account required, and trackers are blocked by default. Your tabs, history, and passwords stay on your computer unless you choose otherwise.

Why it's called Firn: Firn is snow that has made it through a whole season: settled, packed, and on its way to glacier ice. In Swiss German, it means "last year's." A browser made the same way: settled and here to stay.


WHO'S MAKING IT

I'm David. I design and build software, and I live in Salem, Oregon, with my wife and our two boys. I'm also a songwriter: a few of my songs have ended up on network TV, and I play in a band called My Brothers And I.

I make these apps with Claude, an AI from Anthropic, as my coding partner. I decide what each app is and how it should feel: the design, the details, the way it behaves. Claude and I write the code together and catch each other's mistakes.

I build the things I wish already existed: quiet, well-made tools that respect your time and your privacy. If one of them makes your day a little calmer, that's the whole point.


IN THIS FOLDER

logos/         The Firn logo (for light and for dark backgrounds) and the flake, as SVG and PNG
app-icon/      The Mac app icon, 1024 and 512 pixels
screenshots/   Firn on a Mac in light and dark: the sidebar, Lookout, and split view
photo/         David Wurgler


USING THE LOGO

Please use the files as they are: don't redraw, recolor, stretch, or retype the logo. Use firn-logo.svg on light backgrounds and firn-logo-on-dark.svg on dark ones. The name is written "Firn," with a capital F.

Questions, or need something that isn't here? Write to hello@firnbrowser.com.
