FIRN PRESS KIT
firnbrowser.com/press

A calm browser for Mac, iPhone, and iPad.
Vertical tabs, spaces, and split view, without the learning curve.


FACT SHEET

Name:        Firn
Made by:     David Wurgler in Salem, OR
Released:    Firn 1.0 for Mac, October 27, 2026
Platform:    Mac (macOS 14 or later), iPhone (iOS 26 or later), and iPad (iPadOS 26 or later).
Price:       Free
Source:      Open source under MPL-2.0, github.com/dwurgy/firn
Built with:  Swift, SwiftUI, and WebKit, the engine Safari uses
Website:     https://firnbrowser.com
Contact:     hello@firnbrowser.com


SHORT DESCRIPTION

A calm, minimalist browser with vertical tabs, spaces, and split view. Available now for Mac, iPhone, and iPad.


ABOUT FIRN

Spaces: Keep Work and Personal apart, each with its own tabs, sign-ins, and color. Switching feels like opening a different browser.

Basecamp: Your everyday sites, like mail and calendar, one click away at the top of the sidebar. Each space has its own.

Groups: Keep tabs together. Drag one tab onto another to make a group.

Lookout: Peek at a link in a floating panel without leaving your page. Keep it as a tab if you want it.

Split view: Two pages side by side.

Tidied away: Tabs you haven't looked at for a while move quietly into a small button, so the sidebar stays clear.

Nothing collected: No tracking, no telemetry, and no account. Ads and trackers are blocked by default.

Why it's called Firn: Firn is snow that has made it through a whole season: settled, packed, and on its way to glacier ice. In Swiss German, it means "last year's." A browser made the same way: settled and here to stay.


WHO'S MAKING IT

I'm David. I design and build software, and I live in Salem, Oregon, with my wife and our two boys. I'm also a songwriter: a few of my songs have ended up on network TV, and I play in a band called My Brothers And I.

I make these apps with Claude, an AI from Anthropic, as my coding partner. I decide what each app is and how it should feel: the design, the details, the way it behaves. Claude and I write the code together and catch each other's mistakes.

I build the things I wish already existed: quiet, well-made tools that respect your time and your privacy. If one of them makes your day a little calmer, that's the whole point.


IN THIS FOLDER

logos/         The Firn logo (for light and for dark backgrounds) and the flake, as SVG and PNG
app-icon/      The Mac app icon, 1024 and 512 pixels
screenshots/   mac/: Firn on a Mac: the sidebar, a Work space, Lookout, and split view
               iphone/: Firn for iPhone: a page, a tab group,
               the command bar, and Reader
promo/         Five finished images: wide, tall, Firn on a Mac, Firn on an iPhone,
               and your spaces synced with iCloud on a Mac and an iPhone
photo/         David Wurgler


USING THE LOGO

Please use the files as they are: don't redraw, recolor, stretch, or retype the logo. Use firn-logo.svg on light backgrounds and firn-logo-on-dark.svg on dark ones. The name is written "Firn," with a capital F.

Questions, or need something that isn't here? Write to hello@firnbrowser.com.
